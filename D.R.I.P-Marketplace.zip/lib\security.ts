import { NextRequest } from 'next/server';
import jwt from 'jsonwebtoken';

// Security utilities for the D.R.I.P platform

export interface SecurityConfig {
  maxFileSize: number;
  allowedFileTypes: string[];
  rateLimitWindow: number;
  maxRequestsPerWindow: number;
}

export const securityConfig: SecurityConfig = {
  maxFileSize: 50 * 1024 * 1024, // 50MB
  allowedFileTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/webm'],
  rateLimitWindow: 15 * 60 * 1000, // 15 minutes
  maxRequestsPerWindow: 100
};

// Input validation
export function validateInput(data: any, schema: any): boolean {
  try {
    // Basic validation - in production, use a proper validation library like Zod
    if (!data || typeof data !== 'object') return false;
    
    for (const [key, rules] of Object.entries(schema)) {
      if (rules.required && !data[key]) return false;
      if (data[key] && rules.type && typeof data[key] !== rules.type) return false;
      if (data[key] && rules.minLength && data[key].length < rules.minLength) return false;
      if (data[key] && rules.maxLength && data[key].length > rules.maxLength) return false;
    }
    
    return true;
  } catch (error) {
    return false;
  }
}

// File upload validation
export function validateFileUpload(file: File): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No file provided' };
  }
  
  if (file.size > securityConfig.maxFileSize) {
    return { valid: false, error: 'File too large' };
  }
  
  if (!securityConfig.allowedFileTypes.includes(file.type)) {
    return { valid: false, error: 'File type not allowed' };
  }
  
  return { valid: true };
}

// Wallet address validation
export function validateWalletAddress(address: string): boolean {
  if (!address) return false;
  
  // Basic Ethereum address validation
  const ethAddressRegex = /^0x[a-fA-F0-9]{40}$/;
  return ethAddressRegex.test(address);
}

// Transaction hash validation
export function validateTransactionHash(hash: string): boolean {
  if (!hash) return false;
  
  // Basic Ethereum transaction hash validation
  const txHashRegex = /^0x[a-fA-F0-9]{64}$/;
  return txHashRegex.test(hash);
}

// JWT token verification
export function verifyToken(token: string): any {
  try {
    const secret = process.env.JWT_SECRET;
    if (!secret) throw new Error('JWT_SECRET not configured');
    
    return jwt.verify(token, secret);
  } catch (error) {
    return null;
  }
}

// Generate secure token
export function generateToken(payload: any): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET not configured');
  
  return jwt.sign(payload, secret, { expiresIn: '24h' });
}

// Sanitize user input
export function sanitizeInput(input: string): string {
  if (typeof input !== 'string') return '';
  
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
    .replace(/javascript:/gi, '') // Remove javascript: protocols
    .replace(/on\w+\s*=/gi, '') // Remove event handlers
    .trim();
}

// Content access verification
export async function verifyContentAccess(
  contentId: string,
  buyerAddress: string,
  transactionHash: string
): Promise<boolean> {
  try {
    // This would check the database for a valid purchase
    // For now, return true if all parameters are provided
    return !!(contentId && buyerAddress && transactionHash);
  } catch (error) {
    return false;
  }
}

// Log security events
export function logSecurityEvent(event: string, details: any, request: NextRequest) {
  const logEntry = {
    timestamp: new Date().toISOString(),
    event,
    details,
    ip: request.ip || request.headers.get('x-forwarded-for'),
    userAgent: request.headers.get('user-agent'),
    url: request.url
  };
  
  // In production, send to logging service
  console.log('Security Event:', logEntry);
}

// Check if request is from allowed origin
export function isAllowedOrigin(origin: string): boolean {
  const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'];
  return allowedOrigins.includes(origin);
}

// Generate secure random string
export function generateSecureId(length: number = 32): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
