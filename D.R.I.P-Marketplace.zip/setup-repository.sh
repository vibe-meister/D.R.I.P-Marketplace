#!/bin/bash

# D.R.I.P Repository Setup Script
echo "🚀 Setting up D.R.I.P Repository..."

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "📦 Initializing Git repository..."
    git init
    git branch -M main
fi

# Add all files
echo "📁 Adding files to repository..."
git add .

# Create initial commit
echo "💾 Creating initial commit..."
git commit -m "Initial commit: D.R.I.P Decentralized Revenue In Payments

- Complete marketplace platform
- MetaMask integration for payments
- Creator authentication system
- Content management and access control
- Admin dashboard for platform management
- Security middleware and protection
- Private repository setup

Features:
✅ Interactive marketplace with animations
✅ Secure payment processing
✅ Content access control
✅ Creator dashboard
✅ User library system
✅ Admin analytics
✅ Comprehensive security measures"

# Add remote origin (replace with your actual repository URL)
echo "🔗 Adding remote origin..."
git remote add origin https://github.com/vibe-meister/D.R.I.P.git

# Push to GitHub
echo "🚀 Pushing to GitHub..."
git push -u origin main

echo "✅ Repository setup complete!"
echo ""
echo "🔒 IMPORTANT: Make sure to:"
echo "1. Go to GitHub repository settings"
echo "2. Make repository PRIVATE"
echo "3. Set up branch protection rules"
echo "4. Configure environment variables"
echo "5. Deploy to Vercel/Netlify from private repo"
echo ""
echo "📖 See GITHUB_SETUP_GUIDE.md for detailed instructions"
